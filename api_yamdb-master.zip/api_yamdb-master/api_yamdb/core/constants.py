FIELD_LENGTH = {
    'MAX_SIZE': 256,
    'NAME': 150,
    'EMAIL': 254,
    'SLUG': 50
}

USERNAME_PATTERN = r'[\w.@+-]+'
