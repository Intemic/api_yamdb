from datetime import datetime


def current_year():
    return datetime.now().year
